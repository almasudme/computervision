# cable-damage-z5nlo-fsod-epij > 2025-03-12 5:51am
https://universe.roboflow.com/roboflow100vl-fsod/cable-damage-z5nlo-fsod-epij

Provided by a Roboflow user
License: MIT

# Overview
- [Introduction](#introduction)
- [Object Classes](#object-classes)
  - [Break](#break)
  - [Thunderbolt](#thunderbolt)

# Introduction
This dataset is focused on detecting damage on cables. The task involves identifying specific types of cable damage to aid in maintenance and repair efforts. There are two classes of interest:

- **Break**: Represents fractures or breaks in the cable strands.
- **Thunderbolt**: Represents damage that appears as distorted or melted portions of the cable.

# Object Classes

## Break
### Description
The "Break" class represents visible fractures or separations in the cable strands. Breaks are identified by the distinct separation in the strands, often appearing as gaps or sharp discontinuities along the otherwise uniform cable texture.

### Instructions
- Locate and annotate visible breaks where the cable strands are separated.
- Ensure the bounding box includes the entire visible area of separation.
- Do not annotate minor frays or surface scratches that do not fully separate the strands.
- Exclude any reflections or discolorations without physical separation.

## Thunderbolt
### Description
The "Thunderbolt" class represents areas of the cable that appear melted, fused, or heavily distorted. This damage is characterized by irregular shapes and textures compared to the uniform coil of the undamaged cable.

### Instructions
- Locate and annotate areas where the cable appears melted or distorted, differing from the regular pattern.
- Ensure the bounding box captures the full extent of the distortion.
- Do not include areas where the cable is merely dirty or stained without signs of melting or fusion.
- Distinguish from the "Break" class by noting that "Thunderbolt" involves deformation rather than a separation of strands.